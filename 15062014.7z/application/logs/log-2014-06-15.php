<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-15 01:27:30 --> Config Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:27:30 --> URI Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Router Class Initialized
DEBUG - 2014-06-15 01:27:30 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:27:30 --> Output Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Security Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Input Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:27:30 --> Language Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Loader Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:27:30 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:27:30 --> 0
ERROR - 2014-06-15 01:27:30 --> 5
ERROR - 2014-06-15 01:27:30 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) D:\web\vertex\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-06-15 01:27:30 --> 6
ERROR - 2014-06-15 01:27:30 --> Unable to connect to the database
ERROR - 2014-06-15 01:27:30 --> 1
DEBUG - 2014-06-15 01:27:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:27:30 --> Config Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:27:30 --> URI Class Initialized
DEBUG - 2014-06-15 01:27:30 --> Router Class Initialized
ERROR - 2014-06-15 01:27:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-06-15 01:27:50 --> Config Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:27:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:27:50 --> URI Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Router Class Initialized
DEBUG - 2014-06-15 01:27:50 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:27:50 --> Output Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Security Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Input Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:27:50 --> Language Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Loader Class Initialized
DEBUG - 2014-06-15 01:27:50 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:27:50 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:27:50 --> 0
ERROR - 2014-06-15 01:27:50 --> 5
ERROR - 2014-06-15 01:27:50 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) D:\web\vertex\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2014-06-15 01:27:50 --> 6
ERROR - 2014-06-15 01:27:50 --> Unable to connect to the database
ERROR - 2014-06-15 01:27:50 --> 1
DEBUG - 2014-06-15 01:27:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:27:59 --> Config Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:27:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:27:59 --> URI Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Router Class Initialized
DEBUG - 2014-06-15 01:27:59 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:27:59 --> Output Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Security Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Input Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:27:59 --> Language Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Loader Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:27:59 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:27:59 --> 0
ERROR - 2014-06-15 01:27:59 --> 5
ERROR - 2014-06-15 01:27:59 --> 6
ERROR - 2014-06-15 01:27:59 --> 4
DEBUG - 2014-06-15 01:27:59 --> Session Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:27:59 --> A session cookie was not found.
DEBUG - 2014-06-15 01:27:59 --> Session routines successfully run
DEBUG - 2014-06-15 01:27:59 --> Model Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Model Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Controller Class Initialized
DEBUG - 2014-06-15 01:27:59 --> Model Class Initialized
DEBUG - 2014-06-15 01:27:59 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:27:59 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:27:59 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:27:59 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:27:59 --> Final output sent to browser
DEBUG - 2014-06-15 01:27:59 --> Total execution time: 0.0410
DEBUG - 2014-06-15 01:29:05 --> Config Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:29:05 --> URI Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Router Class Initialized
DEBUG - 2014-06-15 01:29:05 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:29:05 --> Output Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Security Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Input Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:29:05 --> Language Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Loader Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:29:05 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:29:05 --> 0
ERROR - 2014-06-15 01:29:05 --> 5
ERROR - 2014-06-15 01:29:05 --> 6
ERROR - 2014-06-15 01:29:05 --> 4
DEBUG - 2014-06-15 01:29:05 --> Session Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:29:05 --> Session routines successfully run
DEBUG - 2014-06-15 01:29:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Controller Class Initialized
DEBUG - 2014-06-15 01:29:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:05 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:29:05 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:29:05 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:29:05 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:29:05 --> Final output sent to browser
DEBUG - 2014-06-15 01:29:05 --> Total execution time: 0.0340
DEBUG - 2014-06-15 01:29:11 --> Config Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:29:11 --> URI Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Router Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Output Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Security Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Input Class Initialized
DEBUG - 2014-06-15 01:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:29:11 --> Language Class Initialized
DEBUG - 2014-06-15 01:29:45 --> Config Class Initialized
DEBUG - 2014-06-15 01:29:45 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:29:45 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:29:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:29:45 --> URI Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Router Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Output Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Security Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Input Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:29:46 --> Language Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Loader Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:29:46 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:29:46 --> 0
ERROR - 2014-06-15 01:29:46 --> 5
ERROR - 2014-06-15 01:29:46 --> 6
ERROR - 2014-06-15 01:29:46 --> 4
DEBUG - 2014-06-15 01:29:46 --> Session Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:29:46 --> Session routines successfully run
DEBUG - 2014-06-15 01:29:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Controller Class Initialized
DEBUG - 2014-06-15 01:29:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:29:46 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:29:46 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:29:46 --> File loaded: application/views/registration_form.php
DEBUG - 2014-06-15 01:29:46 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:29:46 --> Final output sent to browser
DEBUG - 2014-06-15 01:29:46 --> Total execution time: 0.0440
DEBUG - 2014-06-15 01:30:06 --> Config Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:30:06 --> URI Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Router Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Output Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Security Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Input Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:30:06 --> Language Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Loader Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:30:06 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:30:06 --> 0
ERROR - 2014-06-15 01:30:06 --> 5
ERROR - 2014-06-15 01:30:06 --> 6
ERROR - 2014-06-15 01:30:06 --> 4
DEBUG - 2014-06-15 01:30:06 --> Session Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:30:06 --> Session routines successfully run
DEBUG - 2014-06-15 01:30:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Controller Class Initialized
DEBUG - 2014-06-15 01:30:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Config Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:30:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:30:10 --> URI Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Router Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Output Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Security Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Input Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:30:10 --> Language Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Loader Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:30:10 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:30:10 --> 0
ERROR - 2014-06-15 01:30:10 --> 5
ERROR - 2014-06-15 01:30:10 --> 6
ERROR - 2014-06-15 01:30:10 --> 4
DEBUG - 2014-06-15 01:30:10 --> Session Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:30:10 --> Session routines successfully run
DEBUG - 2014-06-15 01:30:10 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Controller Class Initialized
DEBUG - 2014-06-15 01:30:10 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:10 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:30:10 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:30:10 --> File loaded: application/views/registration-confirm-page.php
DEBUG - 2014-06-15 01:30:10 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:30:10 --> Final output sent to browser
DEBUG - 2014-06-15 01:30:10 --> Total execution time: 0.0550
DEBUG - 2014-06-15 01:30:36 --> Config Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:30:36 --> URI Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Router Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Output Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Security Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Input Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:30:36 --> Language Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Loader Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:30:36 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:30:36 --> 0
ERROR - 2014-06-15 01:30:36 --> 5
ERROR - 2014-06-15 01:30:36 --> 6
ERROR - 2014-06-15 01:30:36 --> 4
DEBUG - 2014-06-15 01:30:36 --> Session Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:30:36 --> Session routines successfully run
DEBUG - 2014-06-15 01:30:36 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Controller Class Initialized
DEBUG - 2014-06-15 01:30:36 --> Model Class Initialized
DEBUG - 2014-06-15 01:30:36 --> DB Transaction Failure
ERROR - 2014-06-15 01:30:36 --> Query error: Duplicate entry 'TheHorse' for key 'login'
DEBUG - 2014-06-15 01:30:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:31:05 --> Config Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:31:05 --> URI Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Router Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Output Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Security Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Input Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:31:05 --> Language Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Loader Class Initialized
DEBUG - 2014-06-15 01:31:05 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:31:06 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:31:06 --> 0
ERROR - 2014-06-15 01:31:06 --> 5
ERROR - 2014-06-15 01:31:06 --> 6
ERROR - 2014-06-15 01:31:06 --> 4
DEBUG - 2014-06-15 01:31:06 --> Session Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:31:06 --> Session routines successfully run
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Controller Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> XSS Filtering completed
DEBUG - 2014-06-15 01:31:06 --> XSS Filtering completed
DEBUG - 2014-06-15 01:31:06 --> Config Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:31:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:31:06 --> URI Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Router Class Initialized
DEBUG - 2014-06-15 01:31:06 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:31:06 --> Output Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Security Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Input Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:31:06 --> Language Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Loader Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:31:06 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:31:06 --> 0
ERROR - 2014-06-15 01:31:06 --> 5
ERROR - 2014-06-15 01:31:06 --> 6
ERROR - 2014-06-15 01:31:06 --> 4
DEBUG - 2014-06-15 01:31:06 --> Session Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:31:06 --> Session routines successfully run
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Controller Class Initialized
DEBUG - 2014-06-15 01:31:06 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:06 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:31:06 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:31:06 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:31:06 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:31:06 --> Final output sent to browser
DEBUG - 2014-06-15 01:31:06 --> Total execution time: 0.0290
DEBUG - 2014-06-15 01:31:43 --> Config Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:31:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:31:43 --> URI Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Router Class Initialized
DEBUG - 2014-06-15 01:31:43 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:31:43 --> Output Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Security Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Input Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:31:43 --> Language Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Loader Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:31:43 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:31:43 --> 0
ERROR - 2014-06-15 01:31:43 --> 5
ERROR - 2014-06-15 01:31:43 --> 6
ERROR - 2014-06-15 01:31:43 --> 4
DEBUG - 2014-06-15 01:31:43 --> Session Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:31:43 --> Session routines successfully run
DEBUG - 2014-06-15 01:31:43 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Controller Class Initialized
DEBUG - 2014-06-15 01:31:43 --> Model Class Initialized
DEBUG - 2014-06-15 01:31:43 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:31:43 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:31:43 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:31:43 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:31:43 --> Final output sent to browser
DEBUG - 2014-06-15 01:31:43 --> Total execution time: 0.0400
DEBUG - 2014-06-15 01:32:29 --> Config Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:32:29 --> URI Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Router Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Output Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Security Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Input Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:32:29 --> Language Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Loader Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:32:29 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:32:29 --> 0
ERROR - 2014-06-15 01:32:29 --> 5
ERROR - 2014-06-15 01:32:29 --> 6
ERROR - 2014-06-15 01:32:29 --> 4
DEBUG - 2014-06-15 01:32:29 --> Session Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:32:29 --> Session routines successfully run
DEBUG - 2014-06-15 01:32:29 --> Model Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Model Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Controller Class Initialized
DEBUG - 2014-06-15 01:32:29 --> Model Class Initialized
DEBUG - 2014-06-15 01:32:29 --> XSS Filtering completed
DEBUG - 2014-06-15 01:32:29 --> XSS Filtering completed
DEBUG - 2014-06-15 01:32:29 --> XSS Filtering completed
DEBUG - 2014-06-15 01:32:29 --> XSS Filtering completed
DEBUG - 2014-06-15 01:32:29 --> DB Transaction Failure
ERROR - 2014-06-15 01:32:29 --> Query error: Incorrect datetime value: '2014/06/15 14:00' for function str_to_date
DEBUG - 2014-06-15 01:32:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:37:51 --> Config Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:37:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:37:51 --> URI Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Router Class Initialized
DEBUG - 2014-06-15 01:37:51 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:37:51 --> Output Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Security Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Input Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:37:51 --> Language Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Loader Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:37:51 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:37:51 --> 0
ERROR - 2014-06-15 01:37:51 --> 5
ERROR - 2014-06-15 01:37:51 --> 6
ERROR - 2014-06-15 01:37:51 --> 4
DEBUG - 2014-06-15 01:37:51 --> Session Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:37:51 --> Session routines successfully run
DEBUG - 2014-06-15 01:37:51 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Controller Class Initialized
DEBUG - 2014-06-15 01:37:51 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:51 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:37:51 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:37:51 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:37:51 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:37:51 --> Final output sent to browser
DEBUG - 2014-06-15 01:37:51 --> Total execution time: 0.0300
DEBUG - 2014-06-15 01:37:54 --> Config Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:37:54 --> URI Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Router Class Initialized
DEBUG - 2014-06-15 01:37:54 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:37:54 --> Output Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Security Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Input Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:37:54 --> Language Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Loader Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:37:54 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:37:54 --> 0
ERROR - 2014-06-15 01:37:54 --> 5
ERROR - 2014-06-15 01:37:54 --> 6
ERROR - 2014-06-15 01:37:54 --> 4
DEBUG - 2014-06-15 01:37:54 --> Session Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:37:54 --> Session routines successfully run
DEBUG - 2014-06-15 01:37:54 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Controller Class Initialized
DEBUG - 2014-06-15 01:37:54 --> Model Class Initialized
DEBUG - 2014-06-15 01:37:54 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:37:54 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:37:54 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:37:54 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:37:54 --> Final output sent to browser
DEBUG - 2014-06-15 01:37:54 --> Total execution time: 0.0460
DEBUG - 2014-06-15 01:38:25 --> Config Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:38:25 --> URI Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Router Class Initialized
DEBUG - 2014-06-15 01:38:25 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:38:25 --> Output Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Security Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Input Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:38:25 --> Language Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Loader Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:38:25 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:38:25 --> 0
ERROR - 2014-06-15 01:38:25 --> 5
ERROR - 2014-06-15 01:38:25 --> 6
ERROR - 2014-06-15 01:38:25 --> 4
DEBUG - 2014-06-15 01:38:25 --> Session Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:38:25 --> Session routines successfully run
DEBUG - 2014-06-15 01:38:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Controller Class Initialized
DEBUG - 2014-06-15 01:38:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:38:25 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:38:25 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:38:25 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:38:25 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:38:25 --> Final output sent to browser
DEBUG - 2014-06-15 01:38:25 --> Total execution time: 0.0380
DEBUG - 2014-06-15 01:39:35 --> Config Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:39:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:39:35 --> URI Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Router Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Output Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Security Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Input Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:39:35 --> Language Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Loader Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:39:35 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:39:35 --> 0
ERROR - 2014-06-15 01:39:35 --> 5
ERROR - 2014-06-15 01:39:35 --> 6
ERROR - 2014-06-15 01:39:35 --> 4
DEBUG - 2014-06-15 01:39:35 --> Session Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:39:35 --> Session routines successfully run
DEBUG - 2014-06-15 01:39:35 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Controller Class Initialized
DEBUG - 2014-06-15 01:39:35 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:35 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:35 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:35 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:35 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:35 --> DB Transaction Failure
ERROR - 2014-06-15 01:39:35 --> Query error: Incorrect datetime value: '15.06.2014 11:38' for function str_to_date
DEBUG - 2014-06-15 01:39:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:39:46 --> Config Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:39:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:39:46 --> URI Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Router Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Output Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Security Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Input Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:39:46 --> Language Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Loader Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:39:46 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:39:46 --> 0
ERROR - 2014-06-15 01:39:46 --> 5
ERROR - 2014-06-15 01:39:46 --> 6
ERROR - 2014-06-15 01:39:46 --> 4
DEBUG - 2014-06-15 01:39:46 --> Session Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:39:46 --> Session routines successfully run
DEBUG - 2014-06-15 01:39:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Controller Class Initialized
DEBUG - 2014-06-15 01:39:46 --> Model Class Initialized
DEBUG - 2014-06-15 01:39:46 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:46 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:46 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:46 --> XSS Filtering completed
DEBUG - 2014-06-15 01:39:46 --> DB Transaction Failure
ERROR - 2014-06-15 01:39:46 --> Query error: Incorrect datetime value: '15.06.2014 11:38' for function str_to_date
DEBUG - 2014-06-15 01:39:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:40:28 --> Config Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:40:28 --> URI Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Router Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Output Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Security Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Input Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:40:28 --> Language Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Loader Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:40:28 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:40:28 --> 0
ERROR - 2014-06-15 01:40:28 --> 5
ERROR - 2014-06-15 01:40:28 --> 6
ERROR - 2014-06-15 01:40:28 --> 4
DEBUG - 2014-06-15 01:40:28 --> Session Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:40:28 --> Session routines successfully run
DEBUG - 2014-06-15 01:40:28 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Controller Class Initialized
DEBUG - 2014-06-15 01:40:28 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:28 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:28 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:28 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:28 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:28 --> DB Transaction Failure
ERROR - 2014-06-15 01:40:28 --> Query error: Incorrect datetime value: '15.06.2014 11:38' for function str_to_date
DEBUG - 2014-06-15 01:40:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 01:40:42 --> Config Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:40:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:40:42 --> URI Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Router Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Output Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Security Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Input Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:40:42 --> Language Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Loader Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:40:42 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:40:42 --> 0
ERROR - 2014-06-15 01:40:42 --> 5
ERROR - 2014-06-15 01:40:42 --> 6
ERROR - 2014-06-15 01:40:42 --> 4
DEBUG - 2014-06-15 01:40:42 --> Session Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:40:42 --> Session routines successfully run
DEBUG - 2014-06-15 01:40:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Controller Class Initialized
DEBUG - 2014-06-15 01:40:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:40:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:40:42 --> Final output sent to browser
DEBUG - 2014-06-15 01:40:42 --> Total execution time: 0.0320
DEBUG - 2014-06-15 01:42:16 --> Config Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:42:16 --> URI Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Router Class Initialized
DEBUG - 2014-06-15 01:42:16 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:42:16 --> Output Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Security Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Input Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:42:16 --> Language Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Loader Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:42:16 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:42:16 --> 0
ERROR - 2014-06-15 01:42:16 --> 5
ERROR - 2014-06-15 01:42:16 --> 6
ERROR - 2014-06-15 01:42:16 --> 4
DEBUG - 2014-06-15 01:42:16 --> Session Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:42:16 --> Session routines successfully run
DEBUG - 2014-06-15 01:42:16 --> Model Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Model Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Controller Class Initialized
DEBUG - 2014-06-15 01:42:16 --> Model Class Initialized
DEBUG - 2014-06-15 01:42:16 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:42:16 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:42:16 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:42:16 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:42:16 --> Final output sent to browser
DEBUG - 2014-06-15 01:42:16 --> Total execution time: 0.0450
DEBUG - 2014-06-15 01:43:39 --> Config Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:43:39 --> URI Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Router Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Output Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Security Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Input Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:43:39 --> Language Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Loader Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:43:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:43:39 --> 0
ERROR - 2014-06-15 01:43:39 --> 5
ERROR - 2014-06-15 01:43:39 --> 6
ERROR - 2014-06-15 01:43:39 --> 4
DEBUG - 2014-06-15 01:43:39 --> Session Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:43:39 --> Session routines successfully run
DEBUG - 2014-06-15 01:43:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Controller Class Initialized
DEBUG - 2014-06-15 01:43:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:43:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:43:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:43:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:43:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:43:39 --> Final output sent to browser
DEBUG - 2014-06-15 01:43:39 --> Total execution time: 0.0500
DEBUG - 2014-06-15 01:49:55 --> Config Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:49:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:49:55 --> URI Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Router Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Output Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Security Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Input Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:49:55 --> Language Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Loader Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:49:55 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:49:55 --> 0
ERROR - 2014-06-15 01:49:55 --> 5
ERROR - 2014-06-15 01:49:55 --> 6
ERROR - 2014-06-15 01:49:55 --> 4
DEBUG - 2014-06-15 01:49:55 --> Session Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:49:55 --> Session routines successfully run
DEBUG - 2014-06-15 01:49:55 --> Model Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Model Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Controller Class Initialized
DEBUG - 2014-06-15 01:49:55 --> Model Class Initialized
DEBUG - 2014-06-15 01:49:55 --> XSS Filtering completed
DEBUG - 2014-06-15 01:49:55 --> XSS Filtering completed
DEBUG - 2014-06-15 01:49:55 --> XSS Filtering completed
DEBUG - 2014-06-15 01:49:55 --> XSS Filtering completed
DEBUG - 2014-06-15 01:49:55 --> Final output sent to browser
DEBUG - 2014-06-15 01:49:55 --> Total execution time: 0.0450
DEBUG - 2014-06-15 01:50:01 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:01 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:01 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:01 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:01 --> 0
ERROR - 2014-06-15 01:50:01 --> 5
ERROR - 2014-06-15 01:50:01 --> 6
ERROR - 2014-06-15 01:50:01 --> 4
DEBUG - 2014-06-15 01:50:01 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:01 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:01 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:01 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:01 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:01 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:01 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:01 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:01 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:01 --> Total execution time: 0.0480
DEBUG - 2014-06-15 01:50:05 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:05 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:05 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:05 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:05 --> 0
ERROR - 2014-06-15 01:50:05 --> 5
ERROR - 2014-06-15 01:50:05 --> 6
ERROR - 2014-06-15 01:50:05 --> 4
DEBUG - 2014-06-15 01:50:05 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:05 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:05 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:05 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:05 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:05 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:05 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:05 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:05 --> Total execution time: 0.0570
DEBUG - 2014-06-15 01:50:12 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:12 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:12 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:12 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:12 --> 0
ERROR - 2014-06-15 01:50:12 --> 5
ERROR - 2014-06-15 01:50:12 --> 6
ERROR - 2014-06-15 01:50:12 --> 4
DEBUG - 2014-06-15 01:50:12 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:12 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:12 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:12 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:12 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:12 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:12 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:12 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:12 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:12 --> Total execution time: 0.0470
DEBUG - 2014-06-15 01:50:25 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:25 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:25 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:25 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:25 --> 0
ERROR - 2014-06-15 01:50:25 --> 5
ERROR - 2014-06-15 01:50:25 --> 6
ERROR - 2014-06-15 01:50:25 --> 4
DEBUG - 2014-06-15 01:50:25 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:25 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:25 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:25 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:25 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:25 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:25 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:25 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:25 --> Total execution time: 0.0650
DEBUG - 2014-06-15 01:50:31 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:31 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:31 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:31 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:31 --> 0
ERROR - 2014-06-15 01:50:31 --> 5
ERROR - 2014-06-15 01:50:31 --> 6
ERROR - 2014-06-15 01:50:31 --> 4
DEBUG - 2014-06-15 01:50:31 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:31 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:31 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:31 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:31 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:31 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:31 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:31 --> Total execution time: 0.0530
DEBUG - 2014-06-15 01:50:37 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:37 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:37 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:37 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:37 --> 0
ERROR - 2014-06-15 01:50:37 --> 5
ERROR - 2014-06-15 01:50:37 --> 6
ERROR - 2014-06-15 01:50:37 --> 4
DEBUG - 2014-06-15 01:50:37 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:37 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:37 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:37 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:37 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:37 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:37 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:37 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:37 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:37 --> Total execution time: 0.0460
DEBUG - 2014-06-15 01:50:42 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:42 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:42 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:42 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:42 --> 0
ERROR - 2014-06-15 01:50:42 --> 5
ERROR - 2014-06-15 01:50:42 --> 6
ERROR - 2014-06-15 01:50:42 --> 4
DEBUG - 2014-06-15 01:50:42 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:42 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:42 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:42 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:42 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:42 --> Total execution time: 0.0720
DEBUG - 2014-06-15 01:50:49 --> Config Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:50:49 --> URI Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Router Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Output Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Security Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Input Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:50:49 --> Language Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Loader Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:50:49 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:50:49 --> 0
ERROR - 2014-06-15 01:50:49 --> 5
ERROR - 2014-06-15 01:50:49 --> 6
ERROR - 2014-06-15 01:50:49 --> 4
DEBUG - 2014-06-15 01:50:49 --> Session Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:50:49 --> Session routines successfully run
DEBUG - 2014-06-15 01:50:49 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Controller Class Initialized
DEBUG - 2014-06-15 01:50:49 --> Model Class Initialized
DEBUG - 2014-06-15 01:50:49 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:49 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:49 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:49 --> XSS Filtering completed
DEBUG - 2014-06-15 01:50:49 --> Final output sent to browser
DEBUG - 2014-06-15 01:50:49 --> Total execution time: 0.0470
DEBUG - 2014-06-15 01:55:27 --> Config Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:55:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:55:27 --> URI Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Router Class Initialized
DEBUG - 2014-06-15 01:55:27 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:55:27 --> Output Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Security Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Input Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:55:27 --> Language Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Loader Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:55:27 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:55:27 --> 0
ERROR - 2014-06-15 01:55:27 --> 5
ERROR - 2014-06-15 01:55:27 --> 6
ERROR - 2014-06-15 01:55:27 --> 4
DEBUG - 2014-06-15 01:55:27 --> Session Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:55:27 --> Session routines successfully run
DEBUG - 2014-06-15 01:55:27 --> Model Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Model Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Controller Class Initialized
DEBUG - 2014-06-15 01:55:27 --> Model Class Initialized
DEBUG - 2014-06-15 01:55:27 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:55:27 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:55:27 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:55:27 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:55:27 --> Final output sent to browser
DEBUG - 2014-06-15 01:55:27 --> Total execution time: 0.0510
DEBUG - 2014-06-15 01:56:26 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:26 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:26 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:26 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:56:26 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:26 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:26 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:26 --> 0
ERROR - 2014-06-15 01:56:26 --> 5
ERROR - 2014-06-15 01:56:26 --> 6
ERROR - 2014-06-15 01:56:26 --> 4
DEBUG - 2014-06-15 01:56:26 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:26 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:26 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:26 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:26 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:56:26 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:56:26 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:56:26 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:56:26 --> Final output sent to browser
DEBUG - 2014-06-15 01:56:26 --> Total execution time: 0.0470
DEBUG - 2014-06-15 01:56:30 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:30 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:30 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:30 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:30 --> 0
ERROR - 2014-06-15 01:56:30 --> 5
ERROR - 2014-06-15 01:56:30 --> 6
ERROR - 2014-06-15 01:56:30 --> 4
DEBUG - 2014-06-15 01:56:30 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:30 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:30 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:30 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:56:30 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:30 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:30 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:30 --> 0
ERROR - 2014-06-15 01:56:30 --> 5
ERROR - 2014-06-15 01:56:30 --> 6
ERROR - 2014-06-15 01:56:30 --> 4
DEBUG - 2014-06-15 01:56:30 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:30 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:30 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:30 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:56:30 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:56:30 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:56:30 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:56:30 --> Final output sent to browser
DEBUG - 2014-06-15 01:56:30 --> Total execution time: 0.0240
DEBUG - 2014-06-15 01:56:31 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:31 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:31 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:31 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:31 --> 0
ERROR - 2014-06-15 01:56:31 --> 5
ERROR - 2014-06-15 01:56:31 --> 6
ERROR - 2014-06-15 01:56:31 --> 4
DEBUG - 2014-06-15 01:56:31 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:31 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:31 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:31 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:56:31 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:56:31 --> File loaded: application/views/registration_form.php
DEBUG - 2014-06-15 01:56:31 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:56:31 --> Final output sent to browser
DEBUG - 2014-06-15 01:56:31 --> Total execution time: 0.0500
DEBUG - 2014-06-15 01:56:33 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:33 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:33 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:33 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:33 --> 0
ERROR - 2014-06-15 01:56:33 --> 5
ERROR - 2014-06-15 01:56:33 --> 6
ERROR - 2014-06-15 01:56:33 --> 4
DEBUG - 2014-06-15 01:56:33 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:33 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:33 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:33 --> XSS Filtering completed
DEBUG - 2014-06-15 01:56:33 --> XSS Filtering completed
DEBUG - 2014-06-15 01:56:33 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:33 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:33 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:56:33 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:33 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:33 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:33 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:33 --> 0
ERROR - 2014-06-15 01:56:33 --> 5
ERROR - 2014-06-15 01:56:34 --> 6
ERROR - 2014-06-15 01:56:34 --> 4
DEBUG - 2014-06-15 01:56:34 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:34 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:34 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:34 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:34 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:34 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:34 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:34 --> File loaded: application/views/site/header/login_unlogined.php
DEBUG - 2014-06-15 01:56:34 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:56:34 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:56:34 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:56:34 --> Final output sent to browser
DEBUG - 2014-06-15 01:56:34 --> Total execution time: 0.0330
DEBUG - 2014-06-15 01:56:39 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:39 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:39 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:39 --> 0
ERROR - 2014-06-15 01:56:39 --> 5
ERROR - 2014-06-15 01:56:39 --> 6
ERROR - 2014-06-15 01:56:39 --> 4
DEBUG - 2014-06-15 01:56:39 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:39 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:56:39 --> XSS Filtering completed
DEBUG - 2014-06-15 01:56:39 --> Config Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 01:56:39 --> URI Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Router Class Initialized
DEBUG - 2014-06-15 01:56:39 --> No URI present. Default controller set.
DEBUG - 2014-06-15 01:56:39 --> Output Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Security Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Input Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 01:56:39 --> Language Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Loader Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 01:56:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 01:56:39 --> 0
ERROR - 2014-06-15 01:56:39 --> 5
ERROR - 2014-06-15 01:56:39 --> 6
ERROR - 2014-06-15 01:56:39 --> 4
DEBUG - 2014-06-15 01:56:39 --> Session Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 01:56:39 --> Session routines successfully run
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Controller Class Initialized
DEBUG - 2014-06-15 01:56:39 --> Model Class Initialized
DEBUG - 2014-06-15 01:56:39 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 01:56:39 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 01:56:39 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 01:56:39 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 01:56:39 --> Final output sent to browser
DEBUG - 2014-06-15 01:56:39 --> Total execution time: 0.0290
DEBUG - 2014-06-15 02:10:35 --> Config Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:10:35 --> URI Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Router Class Initialized
DEBUG - 2014-06-15 02:10:35 --> No URI present. Default controller set.
DEBUG - 2014-06-15 02:10:35 --> Output Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Security Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Input Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:10:35 --> Language Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Loader Class Initialized
DEBUG - 2014-06-15 02:10:35 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:10:48 --> Config Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:10:48 --> URI Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Router Class Initialized
DEBUG - 2014-06-15 02:10:48 --> No URI present. Default controller set.
DEBUG - 2014-06-15 02:10:48 --> Output Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Security Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Input Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:10:48 --> Language Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Loader Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:10:48 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:10:48 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:10:48 --> 0
ERROR - 2014-06-15 02:10:48 --> 5
ERROR - 2014-06-15 02:10:48 --> 6
ERROR - 2014-06-15 02:10:48 --> 4
DEBUG - 2014-06-15 02:10:48 --> Session Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:10:48 --> Session routines successfully run
DEBUG - 2014-06-15 02:10:48 --> Model Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Model Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Controller Class Initialized
DEBUG - 2014-06-15 02:10:48 --> Model Class Initialized
DEBUG - 2014-06-15 02:10:48 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 02:10:48 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 02:10:48 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 02:10:48 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 02:10:48 --> Final output sent to browser
DEBUG - 2014-06-15 02:10:48 --> Total execution time: 0.0420
DEBUG - 2014-06-15 02:11:39 --> Config Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:11:39 --> URI Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Router Class Initialized
DEBUG - 2014-06-15 02:11:39 --> No URI present. Default controller set.
DEBUG - 2014-06-15 02:11:39 --> Output Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Security Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Input Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:11:39 --> Language Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Loader Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:11:39 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:11:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:11:39 --> 0
ERROR - 2014-06-15 02:11:39 --> 5
ERROR - 2014-06-15 02:11:39 --> 6
ERROR - 2014-06-15 02:11:39 --> 4
DEBUG - 2014-06-15 02:11:39 --> Session Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:11:39 --> Session routines successfully run
DEBUG - 2014-06-15 02:11:39 --> Model Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Model Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Controller Class Initialized
DEBUG - 2014-06-15 02:11:39 --> Model Class Initialized
DEBUG - 2014-06-15 02:11:39 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 02:11:39 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 02:11:39 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 02:11:39 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 02:11:39 --> Final output sent to browser
DEBUG - 2014-06-15 02:11:39 --> Total execution time: 0.0540
DEBUG - 2014-06-15 02:24:23 --> Config Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:24:23 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:24:23 --> URI Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Router Class Initialized
DEBUG - 2014-06-15 02:24:23 --> No URI present. Default controller set.
DEBUG - 2014-06-15 02:24:23 --> Output Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Security Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Input Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:24:23 --> Language Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Loader Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:24:23 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:24:23 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:24:23 --> 0
ERROR - 2014-06-15 02:24:23 --> 5
ERROR - 2014-06-15 02:24:23 --> 6
ERROR - 2014-06-15 02:24:23 --> 4
DEBUG - 2014-06-15 02:24:23 --> Session Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:24:23 --> Session routines successfully run
DEBUG - 2014-06-15 02:24:23 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Controller Class Initialized
DEBUG - 2014-06-15 02:24:23 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:23 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 02:24:23 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 02:24:23 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 02:24:23 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 02:24:23 --> Final output sent to browser
DEBUG - 2014-06-15 02:24:23 --> Total execution time: 0.0380
DEBUG - 2014-06-15 02:24:30 --> Config Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:24:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:24:30 --> URI Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Router Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Output Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Security Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Input Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:24:30 --> Language Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Loader Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:24:30 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:24:30 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:24:30 --> 0
ERROR - 2014-06-15 02:24:30 --> 5
ERROR - 2014-06-15 02:24:30 --> 6
ERROR - 2014-06-15 02:24:30 --> 4
DEBUG - 2014-06-15 02:24:30 --> Session Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:24:30 --> Session routines successfully run
DEBUG - 2014-06-15 02:24:30 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Controller Class Initialized
DEBUG - 2014-06-15 02:24:30 --> Model Class Initialized
DEBUG - 2014-06-15 02:24:30 --> DB Transaction Failure
ERROR - 2014-06-15 02:24:30 --> Query error: Unknown column 'send_datatime' in 'where clause'
DEBUG - 2014-06-15 02:24:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 02:25:25 --> Config Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:25:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:25:25 --> URI Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Router Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Output Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Security Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Input Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:25:25 --> Language Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Loader Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:25:25 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:25:25 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:25:25 --> 0
ERROR - 2014-06-15 02:25:25 --> 5
ERROR - 2014-06-15 02:25:25 --> 6
ERROR - 2014-06-15 02:25:25 --> 4
DEBUG - 2014-06-15 02:25:25 --> Session Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:25:25 --> Session routines successfully run
DEBUG - 2014-06-15 02:25:25 --> Model Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Model Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Controller Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Model Class Initialized
DEBUG - 2014-06-15 02:25:25 --> Final output sent to browser
DEBUG - 2014-06-15 02:25:25 --> Total execution time: 0.0400
DEBUG - 2014-06-15 02:25:47 --> Config Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:25:47 --> URI Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Router Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Output Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Security Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Input Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:25:47 --> Language Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Loader Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:25:47 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:25:47 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:25:47 --> 0
ERROR - 2014-06-15 02:25:47 --> 5
ERROR - 2014-06-15 02:25:47 --> 6
ERROR - 2014-06-15 02:25:47 --> 4
DEBUG - 2014-06-15 02:25:47 --> Session Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:25:47 --> Session routines successfully run
DEBUG - 2014-06-15 02:25:47 --> Model Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Model Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Controller Class Initialized
DEBUG - 2014-06-15 02:25:47 --> Model Class Initialized
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: text D:\web\vertex\application\controllers\reminder_controller.php 40
ERROR - 2014-06-15 02:25:47 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:25:47 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
DEBUG - 2014-06-15 02:25:47 --> Final output sent to browser
DEBUG - 2014-06-15 02:25:47 --> Total execution time: 0.1040
DEBUG - 2014-06-15 02:26:19 --> Config Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:26:19 --> URI Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Router Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Output Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Security Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Input Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:26:19 --> Language Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Loader Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:26:19 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:26:19 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:26:19 --> 0
ERROR - 2014-06-15 02:26:19 --> 5
ERROR - 2014-06-15 02:26:19 --> 6
ERROR - 2014-06-15 02:26:19 --> 4
DEBUG - 2014-06-15 02:26:19 --> Session Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:26:19 --> Session routines successfully run
DEBUG - 2014-06-15 02:26:19 --> Model Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Model Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Controller Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Model Class Initialized
DEBUG - 2014-06-15 02:26:19 --> Final output sent to browser
DEBUG - 2014-06-15 02:26:19 --> Total execution time: 0.0470
DEBUG - 2014-06-15 02:26:44 --> Config Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:26:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:26:44 --> URI Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Router Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Output Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Security Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Input Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:26:44 --> Language Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Loader Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:26:44 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:26:44 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:26:44 --> 0
ERROR - 2014-06-15 02:26:44 --> 5
ERROR - 2014-06-15 02:26:44 --> 6
ERROR - 2014-06-15 02:26:44 --> 4
DEBUG - 2014-06-15 02:26:44 --> Session Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:26:44 --> Session routines successfully run
DEBUG - 2014-06-15 02:26:44 --> Model Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Model Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Controller Class Initialized
DEBUG - 2014-06-15 02:26:44 --> Model Class Initialized
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
ERROR - 2014-06-15 02:26:44 --> Severity: Warning  --> Missing argument 2 for log_message(), called in D:\web\vertex\application\helpers\send_sms_helper.php on line 6 and defined D:\web\vertex\system\core\Common.php 349
ERROR - 2014-06-15 02:26:44 --> Severity: Notice  --> Undefined variable: message D:\web\vertex\system\core\Common.php 359
DEBUG - 2014-06-15 02:26:44 --> Final output sent to browser
DEBUG - 2014-06-15 02:26:44 --> Total execution time: 0.1020
DEBUG - 2014-06-15 02:27:20 --> Config Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Hooks Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Utf8 Class Initialized
DEBUG - 2014-06-15 02:27:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 02:27:20 --> URI Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Router Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Output Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Security Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Input Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 02:27:20 --> Language Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Loader Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Helper loaded: url_helper
DEBUG - 2014-06-15 02:27:20 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 02:27:20 --> Database Driver Class Initialized
ERROR - 2014-06-15 02:27:20 --> 0
ERROR - 2014-06-15 02:27:20 --> 5
ERROR - 2014-06-15 02:27:20 --> 6
ERROR - 2014-06-15 02:27:20 --> 4
DEBUG - 2014-06-15 02:27:20 --> Session Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Helper loaded: string_helper
DEBUG - 2014-06-15 02:27:20 --> Session routines successfully run
DEBUG - 2014-06-15 02:27:20 --> Model Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Model Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Controller Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Model Class Initialized
DEBUG - 2014-06-15 02:27:20 --> Final output sent to browser
DEBUG - 2014-06-15 02:27:20 --> Total execution time: 0.0820
DEBUG - 2014-06-15 03:12:38 --> Config Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:12:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:12:38 --> URI Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Router Class Initialized
DEBUG - 2014-06-15 03:12:38 --> No URI present. Default controller set.
DEBUG - 2014-06-15 03:12:38 --> Output Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Security Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Input Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:12:38 --> Language Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Loader Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:12:38 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:12:38 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:12:38 --> 0
ERROR - 2014-06-15 03:12:38 --> 5
ERROR - 2014-06-15 03:12:38 --> 6
ERROR - 2014-06-15 03:12:38 --> 4
DEBUG - 2014-06-15 03:12:38 --> Session Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:12:38 --> Session routines successfully run
DEBUG - 2014-06-15 03:12:38 --> Model Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Model Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Controller Class Initialized
DEBUG - 2014-06-15 03:12:38 --> Model Class Initialized
DEBUG - 2014-06-15 03:12:38 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 03:12:38 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 03:12:38 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 03:12:38 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 03:12:38 --> Final output sent to browser
DEBUG - 2014-06-15 03:12:38 --> Total execution time: 0.0340
DEBUG - 2014-06-15 03:13:01 --> Config Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:13:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:13:01 --> URI Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Router Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Output Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Security Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Input Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:13:01 --> Language Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Loader Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:13:01 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:13:01 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:13:01 --> 0
ERROR - 2014-06-15 03:13:01 --> 5
ERROR - 2014-06-15 03:13:01 --> 6
ERROR - 2014-06-15 03:13:01 --> 4
DEBUG - 2014-06-15 03:13:01 --> Session Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:13:01 --> Session routines successfully run
DEBUG - 2014-06-15 03:13:01 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Controller Class Initialized
DEBUG - 2014-06-15 03:13:01 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:01 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:01 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:01 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:01 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:01 --> Final output sent to browser
DEBUG - 2014-06-15 03:13:01 --> Total execution time: 0.0580
DEBUG - 2014-06-15 03:13:28 --> Config Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:13:28 --> URI Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Router Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Output Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Security Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Input Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:13:28 --> Language Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Loader Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:13:28 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:13:28 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:13:28 --> 0
ERROR - 2014-06-15 03:13:28 --> 5
ERROR - 2014-06-15 03:13:28 --> 6
ERROR - 2014-06-15 03:13:28 --> 4
DEBUG - 2014-06-15 03:13:28 --> Session Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:13:28 --> Session routines successfully run
DEBUG - 2014-06-15 03:13:28 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Controller Class Initialized
DEBUG - 2014-06-15 03:13:28 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:28 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:28 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:28 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:28 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:28 --> Final output sent to browser
DEBUG - 2014-06-15 03:13:28 --> Total execution time: 0.0520
DEBUG - 2014-06-15 03:13:32 --> Config Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:13:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:13:32 --> URI Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Router Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Output Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Security Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Input Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:13:32 --> Language Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Loader Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:13:32 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:13:32 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:13:32 --> 0
ERROR - 2014-06-15 03:13:32 --> 5
ERROR - 2014-06-15 03:13:32 --> 6
ERROR - 2014-06-15 03:13:32 --> 4
DEBUG - 2014-06-15 03:13:32 --> Session Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:13:32 --> Session routines successfully run
DEBUG - 2014-06-15 03:13:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Controller Class Initialized
DEBUG - 2014-06-15 03:13:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:32 --> Final output sent to browser
DEBUG - 2014-06-15 03:13:32 --> Total execution time: 0.0430
DEBUG - 2014-06-15 03:13:47 --> Config Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:13:47 --> URI Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Router Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Output Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Security Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Input Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:13:47 --> Language Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Loader Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:13:47 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:13:47 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:13:47 --> 0
ERROR - 2014-06-15 03:13:47 --> 5
ERROR - 2014-06-15 03:13:47 --> 6
ERROR - 2014-06-15 03:13:47 --> 4
DEBUG - 2014-06-15 03:13:47 --> Session Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:13:47 --> Session routines successfully run
DEBUG - 2014-06-15 03:13:47 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Controller Class Initialized
DEBUG - 2014-06-15 03:13:47 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:47 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:47 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:47 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:47 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:47 --> Final output sent to browser
DEBUG - 2014-06-15 03:13:47 --> Total execution time: 0.0650
DEBUG - 2014-06-15 03:13:58 --> Config Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:13:58 --> URI Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Router Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Output Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Security Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Input Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:13:58 --> Language Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Loader Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:13:58 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:13:58 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:13:58 --> 0
ERROR - 2014-06-15 03:13:58 --> 5
ERROR - 2014-06-15 03:13:58 --> 6
ERROR - 2014-06-15 03:13:58 --> 4
DEBUG - 2014-06-15 03:13:58 --> Session Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:13:58 --> Session routines successfully run
DEBUG - 2014-06-15 03:13:58 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Controller Class Initialized
DEBUG - 2014-06-15 03:13:58 --> Model Class Initialized
DEBUG - 2014-06-15 03:13:58 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:58 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:58 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:58 --> XSS Filtering completed
DEBUG - 2014-06-15 03:13:58 --> Final output sent to browser
DEBUG - 2014-06-15 03:13:58 --> Total execution time: 0.0510
DEBUG - 2014-06-15 03:15:06 --> Config Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:15:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:15:06 --> URI Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Router Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Output Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Security Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Input Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:15:06 --> Language Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Loader Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:15:06 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:15:06 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:15:06 --> 0
ERROR - 2014-06-15 03:15:06 --> 5
ERROR - 2014-06-15 03:15:06 --> 6
ERROR - 2014-06-15 03:15:06 --> 4
DEBUG - 2014-06-15 03:15:06 --> Session Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:15:06 --> Session routines successfully run
DEBUG - 2014-06-15 03:15:06 --> Model Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Model Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Controller Class Initialized
DEBUG - 2014-06-15 03:15:06 --> Model Class Initialized
DEBUG - 2014-06-15 03:15:06 --> XSS Filtering completed
DEBUG - 2014-06-15 03:15:06 --> XSS Filtering completed
DEBUG - 2014-06-15 03:15:06 --> XSS Filtering completed
DEBUG - 2014-06-15 03:15:06 --> XSS Filtering completed
DEBUG - 2014-06-15 03:15:06 --> Final output sent to browser
DEBUG - 2014-06-15 03:15:06 --> Total execution time: 0.0450
DEBUG - 2014-06-15 03:33:32 --> Config Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:33:32 --> URI Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Router Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Output Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Security Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Input Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:33:32 --> Language Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Loader Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:33:32 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:33:32 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:33:32 --> 0
ERROR - 2014-06-15 03:33:32 --> 5
ERROR - 2014-06-15 03:33:32 --> 6
ERROR - 2014-06-15 03:33:32 --> 4
DEBUG - 2014-06-15 03:33:32 --> Session Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:33:32 --> Session routines successfully run
DEBUG - 2014-06-15 03:33:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Controller Class Initialized
DEBUG - 2014-06-15 03:33:32 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:32 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:32 --> Final output sent to browser
DEBUG - 2014-06-15 03:33:32 --> Total execution time: 0.0500
DEBUG - 2014-06-15 03:33:41 --> Config Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:33:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:33:41 --> URI Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Router Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Output Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Security Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Input Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:33:41 --> Language Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Loader Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:33:41 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:33:41 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:33:41 --> 0
ERROR - 2014-06-15 03:33:41 --> 5
ERROR - 2014-06-15 03:33:41 --> 6
ERROR - 2014-06-15 03:33:41 --> 4
DEBUG - 2014-06-15 03:33:41 --> Session Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:33:41 --> Session routines successfully run
DEBUG - 2014-06-15 03:33:41 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Controller Class Initialized
DEBUG - 2014-06-15 03:33:41 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:41 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:41 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:41 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:41 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:41 --> Final output sent to browser
DEBUG - 2014-06-15 03:33:41 --> Total execution time: 0.0370
DEBUG - 2014-06-15 03:33:49 --> Config Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:33:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:33:49 --> URI Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Router Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Output Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Security Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Input Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:33:49 --> Language Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Loader Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:33:49 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:33:49 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:33:49 --> 0
ERROR - 2014-06-15 03:33:49 --> 5
ERROR - 2014-06-15 03:33:49 --> 6
ERROR - 2014-06-15 03:33:49 --> 4
DEBUG - 2014-06-15 03:33:49 --> Session Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:33:49 --> Session routines successfully run
DEBUG - 2014-06-15 03:33:49 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Controller Class Initialized
DEBUG - 2014-06-15 03:33:49 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:49 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:49 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:49 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:49 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:49 --> Final output sent to browser
DEBUG - 2014-06-15 03:33:49 --> Total execution time: 0.0510
DEBUG - 2014-06-15 03:33:54 --> Config Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Hooks Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Utf8 Class Initialized
DEBUG - 2014-06-15 03:33:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 03:33:54 --> URI Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Router Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Output Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Security Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Input Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 03:33:54 --> Language Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Loader Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Helper loaded: url_helper
DEBUG - 2014-06-15 03:33:54 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 03:33:54 --> Database Driver Class Initialized
ERROR - 2014-06-15 03:33:54 --> 0
ERROR - 2014-06-15 03:33:54 --> 5
ERROR - 2014-06-15 03:33:54 --> 6
ERROR - 2014-06-15 03:33:54 --> 4
DEBUG - 2014-06-15 03:33:54 --> Session Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Helper loaded: string_helper
DEBUG - 2014-06-15 03:33:54 --> Session routines successfully run
DEBUG - 2014-06-15 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Controller Class Initialized
DEBUG - 2014-06-15 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-15 03:33:54 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:54 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:54 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:54 --> XSS Filtering completed
DEBUG - 2014-06-15 03:33:54 --> Final output sent to browser
DEBUG - 2014-06-15 03:33:54 --> Total execution time: 0.0350
DEBUG - 2014-06-15 04:18:31 --> Config Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:18:31 --> URI Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Router Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Output Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Security Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Input Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:18:31 --> Language Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Loader Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:18:31 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:18:31 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:18:31 --> 0
ERROR - 2014-06-15 04:18:31 --> 5
ERROR - 2014-06-15 04:18:31 --> 6
ERROR - 2014-06-15 04:18:31 --> 4
DEBUG - 2014-06-15 04:18:31 --> Session Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:18:31 --> Session routines successfully run
DEBUG - 2014-06-15 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Controller Class Initialized
DEBUG - 2014-06-15 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-15 04:18:31 --> XSS Filtering completed
DEBUG - 2014-06-15 04:18:31 --> XSS Filtering completed
DEBUG - 2014-06-15 04:18:31 --> XSS Filtering completed
DEBUG - 2014-06-15 04:18:31 --> XSS Filtering completed
DEBUG - 2014-06-15 04:18:31 --> Final output sent to browser
DEBUG - 2014-06-15 04:18:31 --> Total execution time: 0.0480
DEBUG - 2014-06-15 04:21:35 --> Config Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:21:35 --> URI Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Router Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Output Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Security Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Input Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:21:35 --> Language Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Loader Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:21:35 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:21:35 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:21:35 --> 0
ERROR - 2014-06-15 04:21:35 --> 5
ERROR - 2014-06-15 04:21:35 --> 6
ERROR - 2014-06-15 04:21:35 --> 4
DEBUG - 2014-06-15 04:21:35 --> Session Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:21:35 --> Session routines successfully run
DEBUG - 2014-06-15 04:21:35 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Controller Class Initialized
DEBUG - 2014-06-15 04:21:35 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:35 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:35 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:35 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:35 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:35 --> Final output sent to browser
DEBUG - 2014-06-15 04:21:35 --> Total execution time: 0.0450
DEBUG - 2014-06-15 04:21:49 --> Config Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:21:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:21:49 --> URI Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Router Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Output Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Security Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Input Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:21:49 --> Language Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Loader Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:21:49 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:21:49 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:21:49 --> 0
ERROR - 2014-06-15 04:21:49 --> 5
ERROR - 2014-06-15 04:21:49 --> 6
ERROR - 2014-06-15 04:21:49 --> 4
DEBUG - 2014-06-15 04:21:49 --> Session Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:21:49 --> Session routines successfully run
DEBUG - 2014-06-15 04:21:49 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Controller Class Initialized
DEBUG - 2014-06-15 04:21:49 --> Model Class Initialized
DEBUG - 2014-06-15 04:21:49 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:49 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:49 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:49 --> XSS Filtering completed
DEBUG - 2014-06-15 04:21:49 --> Final output sent to browser
DEBUG - 2014-06-15 04:21:49 --> Total execution time: 0.0430
DEBUG - 2014-06-15 04:22:20 --> Config Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:22:20 --> URI Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Router Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Output Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Security Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Input Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:22:20 --> Language Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Loader Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:22:20 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:22:20 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:22:20 --> 0
ERROR - 2014-06-15 04:22:20 --> 5
ERROR - 2014-06-15 04:22:20 --> 6
ERROR - 2014-06-15 04:22:20 --> 4
DEBUG - 2014-06-15 04:22:20 --> Session Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:22:20 --> Session routines successfully run
DEBUG - 2014-06-15 04:22:20 --> Model Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Model Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Controller Class Initialized
DEBUG - 2014-06-15 04:22:20 --> Model Class Initialized
DEBUG - 2014-06-15 04:22:20 --> XSS Filtering completed
DEBUG - 2014-06-15 04:22:20 --> XSS Filtering completed
DEBUG - 2014-06-15 04:22:20 --> XSS Filtering completed
DEBUG - 2014-06-15 04:22:20 --> XSS Filtering completed
DEBUG - 2014-06-15 04:22:20 --> Final output sent to browser
DEBUG - 2014-06-15 04:22:20 --> Total execution time: 0.0500
DEBUG - 2014-06-15 04:23:52 --> Config Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:23:52 --> URI Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Router Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Output Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Security Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Input Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:23:52 --> Language Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Loader Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:23:52 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:23:52 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:23:52 --> 0
ERROR - 2014-06-15 04:23:52 --> 5
ERROR - 2014-06-15 04:23:52 --> 6
ERROR - 2014-06-15 04:23:52 --> 4
DEBUG - 2014-06-15 04:23:52 --> Session Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:23:52 --> Session routines successfully run
DEBUG - 2014-06-15 04:23:52 --> Model Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Model Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Controller Class Initialized
DEBUG - 2014-06-15 04:23:52 --> Model Class Initialized
DEBUG - 2014-06-15 04:23:52 --> XSS Filtering completed
DEBUG - 2014-06-15 04:23:52 --> XSS Filtering completed
DEBUG - 2014-06-15 04:23:52 --> XSS Filtering completed
DEBUG - 2014-06-15 04:23:52 --> XSS Filtering completed
DEBUG - 2014-06-15 04:23:52 --> Final output sent to browser
DEBUG - 2014-06-15 04:23:52 --> Total execution time: 0.0500
DEBUG - 2014-06-15 04:35:30 --> Config Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:35:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:35:30 --> URI Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Router Class Initialized
DEBUG - 2014-06-15 04:35:30 --> No URI present. Default controller set.
DEBUG - 2014-06-15 04:35:30 --> Output Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Security Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Input Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:35:30 --> Language Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Loader Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:35:30 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:35:30 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:35:30 --> 0
ERROR - 2014-06-15 04:35:30 --> 5
ERROR - 2014-06-15 04:35:30 --> 6
ERROR - 2014-06-15 04:35:30 --> 4
DEBUG - 2014-06-15 04:35:30 --> Session Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:35:30 --> Session routines successfully run
DEBUG - 2014-06-15 04:35:30 --> Model Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Model Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Controller Class Initialized
DEBUG - 2014-06-15 04:35:30 --> Model Class Initialized
DEBUG - 2014-06-15 04:35:30 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 04:35:30 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 04:35:30 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 04:35:30 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 04:35:30 --> Final output sent to browser
DEBUG - 2014-06-15 04:35:30 --> Total execution time: 0.0340
DEBUG - 2014-06-15 04:38:39 --> Config Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:38:39 --> URI Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Router Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Output Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Security Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Input Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:38:39 --> Language Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Loader Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:38:39 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:38:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:38:39 --> 0
ERROR - 2014-06-15 04:38:39 --> 5
ERROR - 2014-06-15 04:38:39 --> 6
ERROR - 2014-06-15 04:38:39 --> 4
DEBUG - 2014-06-15 04:38:39 --> Session Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:38:39 --> Session routines successfully run
DEBUG - 2014-06-15 04:38:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Controller Class Initialized
DEBUG - 2014-06-15 04:38:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:39 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:39 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:39 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:39 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:39 --> Final output sent to browser
DEBUG - 2014-06-15 04:38:39 --> Total execution time: 0.0490
DEBUG - 2014-06-15 04:38:47 --> Config Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:38:47 --> URI Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Router Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Output Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Security Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Input Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:38:47 --> Language Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Loader Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:38:47 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:38:47 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:38:47 --> 0
ERROR - 2014-06-15 04:38:47 --> 5
ERROR - 2014-06-15 04:38:47 --> 6
ERROR - 2014-06-15 04:38:47 --> 4
DEBUG - 2014-06-15 04:38:47 --> Session Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:38:47 --> Session routines successfully run
DEBUG - 2014-06-15 04:38:47 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Controller Class Initialized
DEBUG - 2014-06-15 04:38:47 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:47 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:47 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:47 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:47 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:47 --> Final output sent to browser
DEBUG - 2014-06-15 04:38:47 --> Total execution time: 0.0400
DEBUG - 2014-06-15 04:38:56 --> Config Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:38:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:38:56 --> URI Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Router Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Output Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Security Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Input Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:38:56 --> Language Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Loader Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:38:56 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:38:56 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:38:56 --> 0
ERROR - 2014-06-15 04:38:56 --> 5
ERROR - 2014-06-15 04:38:56 --> 6
ERROR - 2014-06-15 04:38:56 --> 4
DEBUG - 2014-06-15 04:38:56 --> Session Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:38:56 --> Session routines successfully run
DEBUG - 2014-06-15 04:38:56 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Controller Class Initialized
DEBUG - 2014-06-15 04:38:56 --> Model Class Initialized
DEBUG - 2014-06-15 04:38:56 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:56 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:56 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:56 --> XSS Filtering completed
DEBUG - 2014-06-15 04:38:56 --> Final output sent to browser
DEBUG - 2014-06-15 04:38:56 --> Total execution time: 0.0460
DEBUG - 2014-06-15 04:39:03 --> Config Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:39:03 --> URI Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Router Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Output Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Security Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Input Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:39:03 --> Language Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Loader Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:39:03 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:39:03 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:39:03 --> 0
ERROR - 2014-06-15 04:39:03 --> 5
ERROR - 2014-06-15 04:39:03 --> 6
ERROR - 2014-06-15 04:39:03 --> 4
DEBUG - 2014-06-15 04:39:03 --> Session Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:39:03 --> Session routines successfully run
DEBUG - 2014-06-15 04:39:03 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Controller Class Initialized
DEBUG - 2014-06-15 04:39:03 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:03 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:03 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:03 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:03 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:03 --> Final output sent to browser
DEBUG - 2014-06-15 04:39:03 --> Total execution time: 0.0350
DEBUG - 2014-06-15 04:39:09 --> Config Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:39:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:39:09 --> URI Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Router Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Output Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Security Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Input Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:39:09 --> Language Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Loader Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:39:09 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:39:09 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:39:09 --> 0
ERROR - 2014-06-15 04:39:09 --> 5
ERROR - 2014-06-15 04:39:09 --> 6
ERROR - 2014-06-15 04:39:09 --> 4
DEBUG - 2014-06-15 04:39:09 --> Session Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:39:09 --> Session routines successfully run
DEBUG - 2014-06-15 04:39:09 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Controller Class Initialized
DEBUG - 2014-06-15 04:39:09 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:09 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:09 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:09 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:09 --> XSS Filtering completed
DEBUG - 2014-06-15 04:39:09 --> Final output sent to browser
DEBUG - 2014-06-15 04:39:09 --> Total execution time: 0.0430
DEBUG - 2014-06-15 04:39:39 --> Config Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:39:39 --> URI Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Router Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Output Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Security Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Input Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:39:39 --> Language Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Loader Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:39:39 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:39:39 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:39:39 --> 0
ERROR - 2014-06-15 04:39:39 --> 5
ERROR - 2014-06-15 04:39:39 --> 6
ERROR - 2014-06-15 04:39:39 --> 4
DEBUG - 2014-06-15 04:39:39 --> Session Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:39:39 --> Session routines successfully run
DEBUG - 2014-06-15 04:39:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Controller Class Initialized
DEBUG - 2014-06-15 04:39:39 --> Model Class Initialized
DEBUG - 2014-06-15 04:39:39 --> DB Transaction Failure
ERROR - 2014-06-15 04:39:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT @currdate := CURDATE();

                INSERT INTO 
                ' at line 3
DEBUG - 2014-06-15 04:39:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 04:40:58 --> Config Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:40:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:40:58 --> URI Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Router Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Output Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Security Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Input Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:40:58 --> Language Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Loader Class Initialized
DEBUG - 2014-06-15 04:40:58 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:40:58 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:40:58 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:40:58 --> 0
ERROR - 2014-06-15 04:40:58 --> 5
ERROR - 2014-06-15 04:40:59 --> 6
ERROR - 2014-06-15 04:40:59 --> 4
DEBUG - 2014-06-15 04:40:59 --> Session Class Initialized
DEBUG - 2014-06-15 04:40:59 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:40:59 --> Session routines successfully run
DEBUG - 2014-06-15 04:40:59 --> Model Class Initialized
DEBUG - 2014-06-15 04:40:59 --> Model Class Initialized
DEBUG - 2014-06-15 04:40:59 --> Controller Class Initialized
DEBUG - 2014-06-15 04:40:59 --> Model Class Initialized
DEBUG - 2014-06-15 04:40:59 --> DB Transaction Failure
ERROR - 2014-06-15 04:40:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT @currdate := CURDATE();

                INSERT INTO 
                ' at line 3
DEBUG - 2014-06-15 04:40:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 04:46:11 --> Config Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:46:11 --> URI Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Router Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Output Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Security Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Input Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:46:11 --> Language Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Loader Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:46:11 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:46:11 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:46:11 --> 0
ERROR - 2014-06-15 04:46:11 --> 5
ERROR - 2014-06-15 04:46:11 --> 6
ERROR - 2014-06-15 04:46:11 --> 4
DEBUG - 2014-06-15 04:46:11 --> Session Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:46:11 --> Session routines successfully run
DEBUG - 2014-06-15 04:46:11 --> Model Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Model Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Controller Class Initialized
DEBUG - 2014-06-15 04:46:11 --> Model Class Initialized
DEBUG - 2014-06-15 04:46:11 --> DB Transaction Failure
ERROR - 2014-06-15 04:46:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INSERT INTO 
                    reminds (user_id, phone_number, send_datetime,' at line 5
DEBUG - 2014-06-15 04:46:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-06-15 04:51:04 --> Config Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:51:04 --> URI Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Router Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Output Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Security Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Input Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:51:04 --> Language Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Loader Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:51:04 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:51:04 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:51:04 --> 0
ERROR - 2014-06-15 04:51:04 --> 5
ERROR - 2014-06-15 04:51:04 --> 6
ERROR - 2014-06-15 04:51:04 --> 4
DEBUG - 2014-06-15 04:51:04 --> Session Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:51:04 --> Session routines successfully run
DEBUG - 2014-06-15 04:51:04 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Controller Class Initialized
DEBUG - 2014-06-15 04:51:04 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Config Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:51:27 --> URI Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Router Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Output Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Security Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Input Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:51:27 --> Language Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Loader Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:51:27 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:51:27 --> 0
ERROR - 2014-06-15 04:51:27 --> 5
ERROR - 2014-06-15 04:51:27 --> 6
ERROR - 2014-06-15 04:51:27 --> 4
DEBUG - 2014-06-15 04:51:27 --> Session Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:51:27 --> Session routines successfully run
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Controller Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Final output sent to browser
DEBUG - 2014-06-15 04:51:27 --> Total execution time: 0.0520
DEBUG - 2014-06-15 04:51:27 --> Config Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:51:27 --> URI Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Router Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Output Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Security Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Input Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:51:27 --> Language Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Loader Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:51:27 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:51:27 --> 0
ERROR - 2014-06-15 04:51:27 --> 5
ERROR - 2014-06-15 04:51:27 --> 6
ERROR - 2014-06-15 04:51:27 --> 4
DEBUG - 2014-06-15 04:51:27 --> Session Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:51:27 --> Session routines successfully run
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Controller Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Model Class Initialized
DEBUG - 2014-06-15 04:51:27 --> Final output sent to browser
DEBUG - 2014-06-15 04:51:27 --> Total execution time: 0.0450
DEBUG - 2014-06-15 04:53:00 --> Config Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:53:00 --> URI Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Router Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Output Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Security Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Input Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:53:00 --> Language Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Loader Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:53:00 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:53:00 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:53:00 --> 0
ERROR - 2014-06-15 04:53:00 --> 5
ERROR - 2014-06-15 04:53:00 --> 6
ERROR - 2014-06-15 04:53:00 --> 4
DEBUG - 2014-06-15 04:53:00 --> Session Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:53:00 --> Session routines successfully run
DEBUG - 2014-06-15 04:53:00 --> Model Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Model Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Controller Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Model Class Initialized
DEBUG - 2014-06-15 04:53:00 --> Final output sent to browser
DEBUG - 2014-06-15 04:53:00 --> Total execution time: 0.0570
DEBUG - 2014-06-15 04:57:18 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:18 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:18 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:18 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:18 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:18 --> 0
ERROR - 2014-06-15 04:57:18 --> 5
ERROR - 2014-06-15 04:57:18 --> 6
ERROR - 2014-06-15 04:57:18 --> 4
DEBUG - 2014-06-15 04:57:18 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:18 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:18 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:18 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:18 --> Total execution time: 0.0640
DEBUG - 2014-06-15 04:57:36 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:36 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:36 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:36 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:37 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:37 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:37 --> 0
ERROR - 2014-06-15 04:57:37 --> 5
ERROR - 2014-06-15 04:57:37 --> 6
ERROR - 2014-06-15 04:57:37 --> 4
DEBUG - 2014-06-15 04:57:37 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:37 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:37 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:37 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:37 --> Total execution time: 0.1270
DEBUG - 2014-06-15 04:57:43 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:43 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:43 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:43 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:43 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:43 --> 0
ERROR - 2014-06-15 04:57:43 --> 5
ERROR - 2014-06-15 04:57:43 --> 6
ERROR - 2014-06-15 04:57:43 --> 4
DEBUG - 2014-06-15 04:57:43 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:43 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:43 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:43 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:43 --> Total execution time: 0.0480
DEBUG - 2014-06-15 04:57:53 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:53 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:53 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:53 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:53 --> 0
ERROR - 2014-06-15 04:57:53 --> 5
ERROR - 2014-06-15 04:57:53 --> 6
ERROR - 2014-06-15 04:57:53 --> 4
DEBUG - 2014-06-15 04:57:53 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:53 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:53 --> Total execution time: 0.0790
DEBUG - 2014-06-15 04:57:53 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:53 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:53 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:53 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:53 --> 0
ERROR - 2014-06-15 04:57:53 --> 5
ERROR - 2014-06-15 04:57:53 --> 6
ERROR - 2014-06-15 04:57:53 --> 4
DEBUG - 2014-06-15 04:57:53 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:53 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:53 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:53 --> Total execution time: 0.0470
DEBUG - 2014-06-15 04:57:54 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:54 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:54 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:54 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:54 --> 0
ERROR - 2014-06-15 04:57:54 --> 5
ERROR - 2014-06-15 04:57:54 --> 6
ERROR - 2014-06-15 04:57:54 --> 4
DEBUG - 2014-06-15 04:57:54 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:54 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:54 --> Total execution time: 0.0570
DEBUG - 2014-06-15 04:57:54 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:54 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:54 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:54 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:54 --> 0
ERROR - 2014-06-15 04:57:54 --> 5
ERROR - 2014-06-15 04:57:54 --> 6
ERROR - 2014-06-15 04:57:54 --> 4
DEBUG - 2014-06-15 04:57:54 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:54 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Config Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:57:54 --> URI Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Router Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Output Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Security Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Input Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:57:54 --> Language Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Loader Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:57:54 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:57:54 --> 0
ERROR - 2014-06-15 04:57:54 --> 5
DEBUG - 2014-06-15 04:57:54 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:54 --> Total execution time: 0.0540
ERROR - 2014-06-15 04:57:54 --> 6
ERROR - 2014-06-15 04:57:54 --> 4
DEBUG - 2014-06-15 04:57:54 --> Session Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:57:54 --> Session routines successfully run
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Controller Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Model Class Initialized
DEBUG - 2014-06-15 04:57:54 --> Final output sent to browser
DEBUG - 2014-06-15 04:57:54 --> Total execution time: 0.0400
DEBUG - 2014-06-15 04:58:33 --> Config Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Hooks Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Utf8 Class Initialized
DEBUG - 2014-06-15 04:58:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-15 04:58:33 --> URI Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Router Class Initialized
DEBUG - 2014-06-15 04:58:33 --> No URI present. Default controller set.
DEBUG - 2014-06-15 04:58:33 --> Output Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Security Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Input Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-15 04:58:33 --> Language Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Loader Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Helper loaded: url_helper
DEBUG - 2014-06-15 04:58:33 --> Helper loaded: send_sms_helper
DEBUG - 2014-06-15 04:58:33 --> Database Driver Class Initialized
ERROR - 2014-06-15 04:58:33 --> 0
ERROR - 2014-06-15 04:58:33 --> 5
ERROR - 2014-06-15 04:58:33 --> 6
ERROR - 2014-06-15 04:58:33 --> 4
DEBUG - 2014-06-15 04:58:33 --> Session Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Helper loaded: string_helper
DEBUG - 2014-06-15 04:58:33 --> Session routines successfully run
DEBUG - 2014-06-15 04:58:33 --> Model Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Model Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Controller Class Initialized
DEBUG - 2014-06-15 04:58:33 --> Model Class Initialized
DEBUG - 2014-06-15 04:58:33 --> File loaded: application/views/site/header/login_logined.php
DEBUG - 2014-06-15 04:58:33 --> File loaded: application/views/site/header/header.php
DEBUG - 2014-06-15 04:58:33 --> File loaded: application/views/site/index.php
DEBUG - 2014-06-15 04:58:33 --> File loaded: application/views/site/footer/footer.php
DEBUG - 2014-06-15 04:58:33 --> Final output sent to browser
DEBUG - 2014-06-15 04:58:33 --> Total execution time: 0.0410
