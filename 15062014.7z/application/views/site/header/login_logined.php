<h3>{username}</h3>
<a href="/users/logoff">
<button type="button" class="btn btn-warning">Log OFF</button>
</a>
<a href="/users/cancel">
    <button type="button" id="cancel" class="btn btn-default">Cancel your account</button>
</a>
