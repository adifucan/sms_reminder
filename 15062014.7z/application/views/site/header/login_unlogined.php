<form class="navbar-form navbar-left" role="form" method="POST" action="users/login">

    <div class="form-group">
        <input type="text" name="login" class="form-control" placeholder="Login">
        <input type="password" name="password" class="form-control" placeholder="Password">
    </div>
    <button type="submit" class="btn btn-info">Login</button>
    <a href="/registration">
        <button type="button" class="btn btn-warning">Register</button>
    </a>
</form>