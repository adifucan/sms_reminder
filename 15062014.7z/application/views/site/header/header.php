<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome to CodeIgniter</title>
</head>
<body>
<div id="wrap">
    <div class="container">
        <div class="row" style="margin: 20px auto">
            <div class="col-md-9">
                <a href="/">
                    <h2>LOGO</h2>
                </a>
            </div>
            <div class="col-md-3">
                {login_page}
            </div>
        </div>